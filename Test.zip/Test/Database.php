<?php
namespace App;

require __DIR__ . '/../vendor/autoload.php';

class Database {
  private $client;
  private $database;
  private $collection;

  public function __construct() {
    $this->client = new MongoDB\Client('mongodb+srv://Vikas:Vikas@1998@cif-database.q7fpwpv.mongodb.net/home');
    $this->database = $this->client->selectDatabase('mydatabase');
    $this->collection = $this->database->selectCollection('users');
  }

  public function findOne($id) {
    return $this->collection->findOne(['_id' => new MongoDB\BSON\ObjectID($id)]);
  }
}
