<?php

namespace App\Testhome\Components\Test;

use MongoDB\Client;


class Index
{
    public function index()
    {
        return $this->connection();
    }

    public function connection()
    {
        $mongoDBConnection = MongoDBConnection::getInstance();
        // Connect to MongoDBe
        $mongoDB = $mongoDBConnection->connect();
        return $mongoDB;
    }
}
