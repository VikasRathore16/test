<?php

namespace App;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;

class Api
{
    private $app;
    private $database;

    public function __construct()
    {
        // $this->app = AppFactory::create();
        // // $this->database = new Database();

        // $this->app->get('/users/{id}', function (Request $request, Response $response, array $args) {
        //     return 'hello';
        //     $user = $this->database->findOne($args['id']);

        //     if ($user) {
        //         $user = new User($user['_id'], $user['name'], $user['email']);
        //         return $response->getBody()->write($user->toJson());
        //     } else {
        //         return $response->withStatus(404)->getBody()->write('User not found');
        //     }
        // });
        $this->app = AppFactory::create();

        $this->app->get('/', function (Request $request, Response $response, $args) {
            $response->getBody()->write("Hello world!");
            return $response;
        });

        $this->app->get('/user/{id}', function (Request $request, Response $response, $args) {
            $response->getBody()->write($args['id']);
            return $response;
        });
    }

    public function run()
    {
        $this->app->run();
    }
}
