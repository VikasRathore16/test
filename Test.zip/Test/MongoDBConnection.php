<?php

namespace App\Testhome\Components\Test;

use MongoDB\Client;

class MongoDBConnection
{

    private  $connectionString  = "mongodb+srv://Vikas:Vikas@1998@cif-database.q7fpwpv.mongodb.net/home";

    // MongoDB connection object
    private $connection = null;

    // Singleton instance
    private static $instance = null;

    // Constructor is private to prevent object creation
    private function __construct()
    {
    }

    // Get the singleton instance
    public static function getInstance()
    {
        if (!self::$instance) {
            self::$instance = new MongoDBConnection();
        }

        return self::$instance;
    }

    // Connect to MongoDB
    public function connect()
    {
        if (!$this->connection) {
            try {
                $this->connection =  new Client($this->connectionString);
            } catch (\Exception $e) {
                die("Failed to connect to MongoDB: {$e->getMessage()}");
            }
        }

        return $this->connection;
    }
}
