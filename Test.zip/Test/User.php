<?php
namespace App;

class User {
  private $id;
  private $name;
  private $email;

  public function __construct($id, $name, $email) {
    $this->id = $id;
    $this->name = $name;
    $this->email = $email;
  }

  public function toJson() {
    return json_encode([
      'id' => $this->id,
      'name' => $this->name,
      'email' => $this->email
    ]);
  }
}
